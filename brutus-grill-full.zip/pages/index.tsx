import Header from '../components/Header';
import ProductCard from '../components/ProductCard';
import Cart from '../components/Cart';

export default function Home() {
  return (
    <div>
      <Header />
      <h1 className="text-3xl font-bold p-4">BRUTUS GRILL</h1>
      <ProductCard />
      <Cart />
    </div>
  );
}
