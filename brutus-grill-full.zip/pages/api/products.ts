export default function handler(req, res) {
  res.status(200).json([
    { id: 1, name: "X-Burger", price: 25 },
    { id: 2, name: "X-Tudo", price: 35 },
    { id: 3, name: "Refrigerante", price: 6 }
  ]);
}
