export default async function handler(req, res) {
  const { MercadoPagoConfig, Preference } = require('mercadopago');
  const client = new MercadoPagoConfig({ accessToken: process.env.MERCADO_PAGO_ACCESS_TOKEN });

  const preference = new Preference(client);
  const result = await preference.create({
    body: {
      items: req.body.items,
      back_urls: {
        success: 'http://localhost:3000/checkout/success',
        failure: 'http://localhost:3000/checkout/failure'
      }
    }
  });

  res.status(200).json({ init_point: result.init_point });
}
