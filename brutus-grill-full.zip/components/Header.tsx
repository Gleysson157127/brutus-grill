export default function Header() {
  return (
    <header className="p-4 bg-black text-white text-center text-xl font-bold">
      BRUTUS GRILL - BARUERI E REGIÃO
    </header>
  );
}
