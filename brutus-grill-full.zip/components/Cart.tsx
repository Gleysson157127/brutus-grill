import { useEffect, useState } from 'react';

export default function Cart() {
  const [cart, setCart] = useState([]);

  useEffect(() => {
    const storedCart = JSON.parse(localStorage.getItem('cart') || '[]');
    setCart(storedCart);
  }, []);

  const checkout = async () => {
    const res = await fetch('/api/payments', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ items: cart.map(c => ({ title: c.name, unit_price: c.price, quantity: 1 })) })
    });
    const data = await res.json();
    window.location.href = data.init_point;
  };

  return (
    <div className="p-4">
      <h2 className="text-2xl font-bold">Carrinho</h2>
      {cart.map((item, index) => (
        <div key={index} className="flex justify-between p-2 border-b">
          <span>{item.name}</span>
          <span>R$ {item.price}</span>
        </div>
      ))}
      <button onClick={checkout} className="mt-4 bg-blue-600 text-white px-4 py-2 rounded">Finalizar Pedido</button>
    </div>
  );
}
