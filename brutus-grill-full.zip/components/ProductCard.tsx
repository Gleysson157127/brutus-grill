import { useEffect, useState } from 'react';

export default function ProductCard() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    fetch('/api/products').then(res => res.json()).then(data => setProducts(data));
  }, []);

  const addToCart = (product) => {
    const cart = JSON.parse(localStorage.getItem('cart') || '[]');
    cart.push(product);
    localStorage.setItem('cart', JSON.stringify(cart));
    alert("Adicionado ao carrinho");
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4">
      {products.map((product) => (
        <div key={product.id} className="border p-4 rounded shadow">
          <h2 className="text-xl font-semibold">{product.name}</h2>
          <p>R$ {product.price}</p>
          <button className="mt-2 bg-green-600 text-white px-4 py-1 rounded"
            onClick={() => addToCart(product)}>Adicionar</button>
        </div>
      ))}
    </div>
  );
}
